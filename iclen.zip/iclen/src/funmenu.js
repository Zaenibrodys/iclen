const funmenu = (prefix) => { 
	return `
✎═─⊱〘 𝐹𝑈𝑁 𝑀𝐸𝑁𝑈 〙⊰══
║
╰─⊱ *${prefix}tebakgambar*
╰─⊱ *${prefix}caklontong*
╰─⊱ *${prefix}family100*
╰─⊱ *${prefix}game*
╰─⊱ *${prefix}truth*
╰─⊱ *${prefix}dare*
╰─⊱ *${prefix}quotes*
╰─⊱ *${prefix}hilih*
╰─⊱ *${prefix}alay* [text]
╰─⊱ *${prefix}simi* [text]
╰─⊱ *${prefix}bucin*
╰─⊱ *${prefix}gtts* [text]
╰─⊱ *${prefix}tts*
║
✎═─⊱〘 ZEEN BOT 〙⊰══`
}
exports.funmenu = funmenu