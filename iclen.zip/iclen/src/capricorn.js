const capricorn = () => { 
	return `       
	
	Beberapa sifat yang cukup menonjol dari orang yang mempunyai zodiak Capricorn yaitu mengutamakan reputasi, kesuksesan, jabatan, loyal, status, bijaksana, takut akan hambatan, bertanggung jawab, pesimis, rendah diri, berfikir sempit dan memiliki rasa khawatir yang berlebihan.`
	}
exports.capricorn = capricorn
	