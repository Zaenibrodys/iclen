const prefix = (prefix) => { 
	return `
	PREFIX YANG SAAT INI DIGUNAKAN *「* ${prefix} *」
	`
	}
exports.prefix = prefix